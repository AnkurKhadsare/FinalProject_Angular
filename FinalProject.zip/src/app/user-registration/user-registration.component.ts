import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {

  errorMessage:string;
  message:string;
  constructor(private capbookService:CapBookService) { }

  registrationForm = new FormGroup({
    emailId: new FormControl(''),
    password: new FormControl(''),
    confirmPassword: new FormControl(''),
  })


  onSubmit():void{
    console.log("In OnSubmit")
    if((this.registrationForm.get('password').value)!=(this.registrationForm.get('confirmPassword').value)){
      console.log("In If")
      this.errorMessage="Password Does Not Match";
    }
    else{
      console.log("In Else")
    /* this.capbookService.userRegistration(this.registrationForm).subscribe(
      message=>{
        this.message=message;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    )
 */    }
  }

  ngOnInit() {
  }

}
